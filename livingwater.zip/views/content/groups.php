<section class="long-distance container-fluid">
    <div class="row">
        <div class="col-md-3">
            <img src="assets/imgs/misc/groups.jpg" class="section-img mb-4">
        </div>
        <div class="col-8 col-md-8 ps-md-5">
            <h1 class="title">Groups</h1>
            <hr class="mt-1">
            <p>
            Living waters Medtransport LLC vehicles can carry multiple patients at the same time, therefore we mantain the incidents
            incidents to the mínimum and keep everyone safe.
            <br><br>
            Our company have participated in many situatios such emergencies or evacuations and assure the group travel safety and
            provide a comfortable and secure journey.
            <br><br>
            Don't hesitate in contact with us if you need any kind 
            Please contact us now to give us the details of your needs and we will work with you on the best available options.
            </p>

            <button class="btn btn-classic mt-4" onclick="begin()">Begin your journey</button>
        </div>
    </div>
</section>