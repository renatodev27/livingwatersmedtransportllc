<link rel="stylesheet" href="<?php echo SERVER_URL ?>assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo SERVER_URL ?>assets/css/swiper-bundle.min.css">
<link rel="stylesheet" href="<?php echo SERVER_URL ?>assets/css/main.css">