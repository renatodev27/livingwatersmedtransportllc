<?php if (!$is_principal) : ?>
    <script src="<?php echo SERVER_URL ?>assets/js/bootstrap.bundle.js"></script>
<?php else : ?>
    <script src="<?php echo SERVER_URL ?>assets/js/bootstrap.min.js"></script>
<?php endif; ?>
<script src="<?php echo SERVER_URL ?>assets/js/fontawesome.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo SERVER_URL ?>assets/js/swiper-bundle.min.js"></script>
<script src="<?php echo SERVER_URL ?>assets/js/main.js"></script>