<?php 

const SERVER_URL = 'http://localhost/livingwatersmedtransportllc/project/api/';
//const SERVER_URL = 'https://livingwatersmedtransportllc-renatodev27.vercel.app/';

?>
